Конспект для сохранения
https://docs.google.com/document/d/1zemT09J6UDzF2ol3qgl9B_gp_Hl5Sr5wHWzSH2Aks-0/edit?usp=sharing

Группа https://vk.com/jsspec
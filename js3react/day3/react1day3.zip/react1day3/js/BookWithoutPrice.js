class BookWithoutPrice extends React.Component{
  constructor(props){
    super(props);
    this.state = {selected: false};
    this.handlerClick = this.handlerClick.bind(this);
  }  
  
  handlerClick(e){
    e.preventDefault();
    //alert(this);
    this.setState({selected: !this.state.selected});
  }

  render(){
  
  const cssClass = this.state.selected ? 'book-selected' : 'book-default'
 
  return <div className={'book '+cssClass} >
 <h3>{this.props.title}</h3>
 <img src={'http://placehold.it/100x120?text='+this.props.title} />
 <p>Автор: {this.props.author}</p>
 <p>Цена: &nbsp;- руб.</p>
  <a href="#" onClick={this.handlerClick}>Сравнить </a>
</div>
  }
}

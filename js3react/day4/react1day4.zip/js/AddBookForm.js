class AddBookForm extends React.Component{
  constructor(props){
    super(props);
    this.state  = {
     id: 0,
     title: '',
     author: '',
     price: null
    }
    this.handleSubmit = this.handleSubmit.bind(this); 
    this.handleChange = this.handleChange.bind(this); 
  }
  handleSubmit(e){
    e.preventDefault();
    if( this.isValidBook(this.state) ){
      //dataBook.push(this.state);
      this.props.handleAddBook(this.state);    
      //console.log(dataBook);
    } else alert('Заполните все поля');
  }
  handleChange(e){
    const input = {};
    input[e.target.name] = e.target.value;
    this.setState(input);
    //setTimeout(()=>{alert(this.state.title)},3000)
  }  
  
  isValidBook(book){
    console.log(book);
    return book.id && book.title && book.author ? true: false;
  }
  
  render(){
    return <form action="" onSubmit={this.handleSubmit} >
  <div>id <input type="text" name="id" onChange={this.handleChange} value={this.state.id} /></div>
  <div>Название <input type="text" name="title" onChange={this.handleChange} value={this.state.title} /></div>
  <div>Авторы <input type="text" name="author" onChange={this.handleChange} value={this.state.author}  /></div>
  <div>Цена <input type="text" name="price" onChange={this.handleChange} value={this.state.price}  /></div>
  <div><input type="submit" value="Добавить" /></div>
</form>
 ;
  }
}
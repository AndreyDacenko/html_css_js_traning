class App extends React.Component {
    
  constructor(props){
      super(props);
      this.state = {
          dataBook : this.props.dataBook,
          items: {}
      };
      this.addBasket = this.addBasket.bind(this);
      this.addBook   = this.addBook.bind(this);
      this.removeBasket = this.removeBasket.bind(this);
  }    
    
  removeBasket(id){
    let items = Object.assign({},this.state.items);
    let result = {};  
    for(let i in items){
        if(id != i) result[i] = items[i];
    }  
    this.setState({items: result});
  }
  addBasket(id){
    const items = Object.assign({},this.state.items);
    items[id] = id in items ? items[id]+1 : 1;
    console.log('Теперь в корзине:',items); 
    this.setState({items: items});  
  }    
  addBook(book){
     const newDataBook = Object.assign([],this.state.dataBook);
     newDataBook.push(book);  
     console.log('Теперь в App:',newDataBook); 
     this.setState({dataBook: newDataBook}); 
  }    
    
  render(){    
  const bmi = this.props.weight / ( (this.props.height / 100) ** 2 );
  const dataBook = this.state.dataBook;
  const callbackAddBasket = this.addBasket; 
      
  return <div>
    Индекс массы тела: {bmi}
    <Basket items={this.state.items} dataBook={this.props.dataBook} handleRemoveBasket={this.removeBasket} />
        
    <AddBookForm handleAddBook={this.addBook} />
  
    {dataBook.map( function(book){
     return 'price' in book ? <Book 
        title={book.title} 
        price={book.price}
        author={book.author}
        id={book.id}
        key={book.id}
        handleAddBasket={callbackAddBasket}
      /> : <BookWithoutPrice 
        title={book.title} 
        author={book.author}
        id={book.id}
        key={book.id}
      />
   })}                                                  
  
    <Footer phone="+7(495)780-47-50" />

 </div>
    }
}

class Basket extends React.Component{
    constructor(props){
        super(props);
        this.getIndexById = this.getIndexById.bind(this);
        this.deleteBasketItem = this.deleteBasketItem.bind(this);
    }
    getIndexById(id){
        const dataBook = this.props.dataBook;
        for(let j in dataBook)
            if(id == dataBook[j]['id'])
                return j;
    }
    deleteBasketItem(e){
        e.preventDefault();
        this.props.handleRemoveBasket(e.target.id);
    }
    render(){
        let items = this.props.items;
        let dataBook = this.props.dataBook;
        let goods = [], j, summa = 0;
        /*
         {'23':2,'4':1}
        */
        for(let i in items){
           j = this.getIndexById(i);    
           goods.push(<div className="basket-item">
            <a href="#">{dataBook[j]['title']}</a>
            <span>{items[i]}шт.</span>                      
            <span>{dataBook[j]['price']}</span> 
            <a href="#" onClick={this.deleteBasketItem} id={i} >Удалить</a>       
           </div>); 
           summa += items[i] * dataBook[j]['price'];         
        }
        
        //вывод общей суммы в корзине
        goods.push(<div className="basket-item">               
            <span>Всего: {summa}руб.</span>     
           </div>);              
                      
        return <div className="basket">
            <h2>Корзина</h2>
            {goods}
        </div>;    
    }
}
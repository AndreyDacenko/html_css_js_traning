Конспект курса доступен только во время занятий: https://docs.google.com/document/d/1_CBGObhm20YCj6y-iYGDVd7-uHIzg_OuwrUhnYNq9a0/edit?usp=sharing

Сохраните конспект по курсу в виде PDF-файла, пока он доступен во время занятия
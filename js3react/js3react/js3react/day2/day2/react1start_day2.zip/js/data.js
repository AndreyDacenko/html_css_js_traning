const dataBook = [
  {id:1, title:"React.js. Быстрый старт", author:"Стоян Стефанов", price: 700},
  {id:5, title:"React и Redux", author:"Алекс Бэнкс, Ева Порсело", price: 950},
  {id:6, title:"The Road to learn React", author:"Robin Wieruch", price: 1300},
  {id:8, title:"ECMAScript 6 для разработчиков", author:"Николас Закас", price: 960},
  {id:9, title:"Front-end. Клиентская разработка", author:"Крис Аквино, Тодд Ганди", price: 1200},
];

